package handler

import (
	"fmt"
	"html/template"
	"io"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"github.com/hawltu/project1/user"
	"github.com/hawltu/project1/item"
	"github.com/hawltu/project1/entity"
	"strconv"
	//"github.com/satori/go.uuid"
)

type ItemHandler struct {
	tmpl   *template.Template
	serSrv item.ItemService
	usrSer  user.UserService
}

func NewItemrHandler(T *template.Template, US item.ItemService,USS user.UserService) *ItemHandler {
	return &ItemHandler{tmpl: T, serSrv: US,usrSer: USS}
}

/*func (cph *ItemtHandler) ItemPosts(w http.ResponseWriter, r *http.Request) {

	var cookie, cerr = r.Cookie("session")
	if cerr != nil {
		fmt.Println("no cookie")
		http.Redirect(w, r, "/cmp", http.StatusSeeOther)
		return
	}

	s, serr := cph.serSrv.Session(cookie.Value)
	if len(serr) > 0 {
		panic(serr)
	}

	authorizedPost := []entity.Item{}

	posts, errs := cph.serSrv.Items()
	if len(errs) > 0 {
		panic(errs)
	}
	for _, post := range posts {
		if s.ID == post.ID {
			authorizedPost = append(authorizedPost, post)
		}
	}

	cph.tmpl.ExecuteTemplate(w, "upload.html", authorizedPost)
}*/
func (cph *ItemHandler) UploadItem(w http.ResponseWriter, r *http.Request) {

	//fmt.Println("companypostsnew function invoked! ")
	cookie, err := r.Cookie("session")
	if r.Method == http.MethodPost {

		fmt.Println("post method verified! ")

		if err == nil {
			cookievalue := cookie.Value
			fmt.Println(cookievalue)
		}
	
		s, serr := cph.usrSer.Session(cookie.Value)

		if len(serr) > 0 {
			panic(serr)
		}

		fmt.Println("userid",s.UserID)
		post := &entity.Item{}
		post.UserID = s.UserID
		post.Name  = r.FormValue("name")
		post.Catagory = r.FormValue("catagory")
		xx := r.FormValue("catagory")
		fmt.Println("catagory",xx)
		post.Subcatagory = r.FormValue("subcatagory")
		x,_ := strconv.Atoi(r.FormValue("price"))
		post.Price = x
		y,_:= strconv.Atoi(r.FormValue("quantity"))
		post.Quantity = y
		fmt.Println("quantity is", y)
		//fmt.Println(post.Catagory)
		mf, fh, err := r.FormFile("image")
		if err != nil {
			panic(err)
		}
		defer mf.Close()

		post.Image = fh.Filename
		fmt.Println("the name of image",fh.Filename)
		writeFile1(&mf, fh.Filename)

		/*cmp, cerr := cph.usrSer.User(s.ID)

		if len(cerr) > 0 {
			fmt.Println("i am the error")
			panic(cerr)
		}*/

		//fmt.Println(cmp.Name)

	

		fmt.Println(post)
		_,errs := cph.serSrv.StoreItem(post)
		/*if len(errs) > 0{
			panic(errs)
		}*/
		
		///fmt.Println("post added to db")
		fmt.Println(errs)
		http.Redirect(w, r, "/log", http.StatusSeeOther)

	}else {
		fmt.Println("is else statement")
		cph.tmpl.ExecuteTemplate(w, "register.html", nil)

	}
}
/*func (cph *ItemHandler) UpdateItem(w http.ResponseWriter, r *http.Request) {

	fmt.Println("companypostsnew function invoked! ")

	if r.Method == http.MethodPost {

		fmt.Println("post method verified! ")

		var cookie, err = r.Cookie("session")
		if err == nil {
			cookievalue := cookie.Value
			fmt.Println(cookievalue)
		}

		s, serr := cph.usrSer.Session(cookie.Value)

		if len(serr) > 0 {
			panic(serr)
		}

		fmt.Println(s.ID)

		/*cmp, cerr := cph.usrSer.User(s.ID)

		if len(cerr) > 0 {
			fmt.Println("i am the error")
			panic(cerr)
		}

		//fmt.Println(cmp.Name)

		post := &entity.Item{}
		post.UserID = s.UserID
		post.Catagory = r.FormValue("catagory")
		post.Subcatagory = r.FormValue("subcatagory")
		
		x,_ := strconv.Atoi(r.FormValue("price"))
		post.Price = x
		y,_:= strconv.Atoi(r.FormValue("quantity"))	
		post.Quantity = y
		fmt.Println(post.Catagory)
		mf, fh, err := r.FormFile("image")
		if err != nil {
			panic(err)
		}
		defer mf.Close()

		post.Image = fh.Filename

		writeFile1(&mf, fh.Filename)

		_,errs := cph.serSrv.StoreItem(post)
		if errs != nil {
			panic(errs)
		}
		fmt.Println(post)
		fmt.Println("post added to db")

		http.Redirect(w, r, "/log", http.StatusSeeOther)

	}else {
		fmt.Println("is else statement")
		cph.tmpl.ExecuteTemplate(w, "register.html", nil)

	}
}*/
func writeFile1(mf *multipart.File, fname string) {

	wd, err := os.Getwd()

	if err != nil {
		panic(err)
	}

	path := filepath.Join(wd, "../../", "ui", "assets", "image", fname)
	image, err := os.Create(path)

	/*if err != nil {
		panic(err)
	}*/
	defer image.Close()
	io.Copy(image, *mf)
}

func (uh *ItemHandler) Logingg(w http.ResponseWriter, r *http.Request) {


	//get cookie
	/*s, err := r.Cookie("session")
	if err != nil {
		fmt.Println("no cookie")
		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}
	user, _ := uh.userSrv.Users()
*/
	uh.tmpl.ExecuteTemplate(w, "register.html", nil)
}
func (uh *ItemHandler) ItemByCatagoryMen(w http.ResponseWriter, r *http.Request){
	var mencategories  = []entity.Item{}
	itms,_ := uh.serSrv.Items()
	men := "men"
	for _, tt := range itms {
		if  tt.Catagory == men{
			mencategories = append(mencategories,tt)
			//uh.tmpl.ExecuteTemplate(w,"kids.html",kidcategories)
		}
	}
	uh.tmpl.ExecuteTemplate(w,"men.html",mencategories)
}
func (uh *ItemHandler) ItemByCatagoryKid(w http.ResponseWriter, r *http.Request) {
	var kidcategories   =  []entity.Item{}
	kid := "kid"
	itms,_ := uh.serSrv.Items()
	for _, tt := range itms{
		if  tt.Catagory == kid {
			kidcategories = append(kidcategories,tt)
		}
	}
	uh.tmpl.ExecuteTemplate(w,"kids.html",kidcategories)
}
func (uh *ItemHandler) ItemByCatagoryWomen(w http.ResponseWriter, r *http.Request) {
	itms,_ := uh.serSrv.Items()
	var womencategories   =  []entity.Item{}
	women := "women"
	for _, tt := range itms {
		if  tt.Catagory == women {
			womencategories = append(womencategories,tt)
			//uh.tmpl.ExecuteTemplate(w,"kids.html",kidcategories)
		}
	}
	uh.tmpl.ExecuteTemplate(w,"women.html",womencategories)
}
func (uh *ItemHandler) ItemByCatagoryTech(w http.ResponseWriter, r *http.Request) {
	var Techcategories   =  []entity.Item{}
	tech := "tech"
	itms,_ := uh.serSrv.Items()
	for _, tt := range itms {
		if  tt.Catagory == tech {
			Techcategories = append(Techcategories,tt)
			//uh.tmpl.ExecuteTemplate(w,"kids.html",kidcategories)
		}
	}
	uh.tmpl.ExecuteTemplate(w,"tech.html",Techcategories)
}